import { error, json } from '@sveltejs/kit';
import { getBrainContexts } from '$lib/server/brain/getBrainContexts';
import { getBrainPage } from '$lib/server/brain/getBrainPage';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ locals, params }) => {
	const { user } = await locals.safeGetSession();
	if (user === null) error(401, 'Sign in to read your Domain Brain');

	const page = await getBrainPage(locals.supabase, params.slug);
	if (page === null) error(404, 'That page is not in your Domain Brain');
	const contexts = await getBrainContexts(locals.supabase);
	const context = contexts.find((candidate) => candidate.slug === page.contextSlug) ?? null;
	return json({ page, contextName: context?.name ?? null });
};
